class Number:
    def __init__(self, number):
        self.number = number
        
#     def __str__(self):
#         return str(self.number)
    
    def add_one(self):
        self_number = self.number + 1