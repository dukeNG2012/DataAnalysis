import numpy as np

def calculate(list):
    return calculations